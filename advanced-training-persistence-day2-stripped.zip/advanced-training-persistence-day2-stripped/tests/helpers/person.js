import Model from 'appkit/microdata/model';
import attr from 'appkit/microdata/attr';

export default Model.extend({
  firstName: attr(),
  lastName: attr()
});

