export default Ember.Object.extend({

});
