export default Ember.View.extend({
  classNames: ['user-show']
});
