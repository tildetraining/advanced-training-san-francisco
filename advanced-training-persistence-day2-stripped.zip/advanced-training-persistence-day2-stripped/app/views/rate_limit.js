export default Em.View.extend({
  classNames: ['rate-limit']
});
