export default Ember.Route.extend({

});
