/* global ic */
export default function ajax(){
  return ic.ajax.apply(null, arguments);
}
