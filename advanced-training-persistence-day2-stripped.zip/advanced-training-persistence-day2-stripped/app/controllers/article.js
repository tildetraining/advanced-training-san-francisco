export default Ember.ObjectController.extend();
