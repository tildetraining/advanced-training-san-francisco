module.exports = {
  'debug': ['tmp'],
  'dist': ['tmp', 'dist']
};
